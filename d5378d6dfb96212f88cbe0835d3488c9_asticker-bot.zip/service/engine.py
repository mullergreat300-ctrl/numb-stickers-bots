"""
A-sticker conversion engine.
Video -> WhatsApp-ready animated WebP sticker (silent, 512x512, <=3s, <=500KB)
        + extracted audio as an OGG/Opus voice note.
"""
import os
import subprocess
import imageio_ffmpeg

FF = imageio_ffmpeg.get_ffmpeg_exe()
MAX_SECONDS = 3
MAX_BYTES = 500 * 1024
SIZE = 512


def _run(args):
    return subprocess.run(args, capture_output=True, text=True)


def has_audio(path: str) -> bool:
    r = _run([FF, "-i", path, "-hide_banner"])
    return "Audio:" in (r.stderr or "")


def make_sticker(src: str, out: str, seconds: int = MAX_SECONDS, fps: int = 15):
    """Silent animated WebP, 512x512, capped length, quality lowered until <500KB."""
    vf = (
        f"crop='min(iw,ih)':'min(iw,ih)',"
        f"scale={SIZE}:{SIZE}:flags=lanczos,fps={fps}"
    )
    q = 70
    size = 0
    while q >= 15:
        _run([
            FF, "-y", "-t", str(seconds), "-i", src,
            "-vf", vf, "-an",
            "-c:v", "libwebp", "-lossless", "0", "-q:v", str(q),
            "-loop", "0", "-f", "webp", out,
        ])
        size = os.path.getsize(out) if os.path.exists(out) else 0
        if 0 < size <= MAX_BYTES:
            break
        q -= 10
    return out, size


def make_audio(src: str, out: str):
    """Extract audio to OGG/Opus (WhatsApp voice-note friendly). Returns path or None."""
    if not has_audio(src):
        return None
    _run([
        FF, "-y", "-i", src, "-vn",
        "-c:a", "libopus", "-b:a", "64k",
        "-ar", "48000", "-ac", "1", out,
    ])
    return out if os.path.exists(out) else None


def convert(src: str, out_dir: str):
    os.makedirs(out_dir, exist_ok=True)
    sticker = os.path.join(out_dir, "sticker.webp")
    audio = os.path.join(out_dir, "audio.ogg")
    s_path, s_size = make_sticker(src, sticker)
    a_path = make_audio(src, audio)
    return {
        "sticker": s_path if s_size else None,
        "sticker_bytes": s_size,
        "sticker_ok": bool(s_size and s_size <= MAX_BYTES),
        "audio": a_path,
        "had_audio": has_audio(src),
    }
